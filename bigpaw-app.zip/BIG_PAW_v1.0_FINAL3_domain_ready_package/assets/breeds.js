(function(){
  const breeds = [{"key": "golden", "name": "ゴールデンレトリーバー"}, {"key": "goldendoodle", "name": "ゴールデンドゥードル:ゴールデンレトリーバー×プードル"}, {"key": "standard", "name": "スタンダードプードル"}, {"key": "husky", "name": "シベリアンハスキー"}, {"key": "labrador", "name": "ラブラドールレトリーバー"}, {"key": "samoyed", "name": "サモエド"}, {"key": "doberman", "name": "ドーベルマン"}, {"key": "malamute", "name": "アラスカンマラミュート"}, {"key": "labradoodle", "name": "ラブラドゥードル:ラブラドールレトリーバー×プードル"}, {"key": "bernedoodle", "name": "バーニードゥードル:バーニーズ×スタンダードプードル"}, {"key": "german-shepherd", "name": "ジャーマンシェパードドッグ"}, {"key": "akita", "name": "秋田犬"}, {"key": "flat-coated-retriever", "name": "フラットコーテッドレトリーバー"}, {"key": "dalmatian", "name": "ダルメシアン"}, {"key": "old-english-sheepdog", "name": "オールドイングリッシュシープドッグ"}, {"key": "bernese", "name": "バーニーズマウンテンドッグ"}, {"key": "white-shepherd", "name": "ホワイトシェパード"}, {"key": "saint-bernard", "name": "セントバーナード"}, {"key": "great-dane", "name": "グレートデン"}, {"key": "newfoundland", "name": "ニューファンドランド"}, {"key": "chow-chow", "name": "チャウチャウ"}, {"key": "rottweiler", "name": "ロットワイラー"}, {"key": "weimaraner", "name": "ワイマラナー"}, {"key": "boxer", "name": "ボクサー"}, {"key": "rough-collie", "name": "ラフコリー"}, {"key": "pyrenees", "name": "グレートピレニーズ"}, {"key": "cane-corso", "name": "イタリアンコルソドッグ(カネコルソ)"}, {"key": "borzoi", "name": "ボルゾイ"}, {"key": "czechoslovakian-wolfdog", "name": "チェコスロバキアンウルフドッグ"}, {"key": "giant-schnauzer", "name": "ジャイアントシュナウザー"}, {"key": "german-pointer", "name": "ジャーマンポインター"}, {"key": "borzoi-doodle", "name": "ボルゾイドゥードル:ボルゾイ×スタンダードプードル"}, {"key": "afghan-hound", "name": "アフガンハウンド"}, {"key": "belgian-tervuren", "name": "ベルジアンシェパードドッグ(タービュレン)"}, {"key": "american-akita", "name": "アメリカン・アキタ"}, {"key": "dogo-argentino", "name": "ドゴアルヘンティーノ"}, {"key": "presa-canario", "name": "プレサカナリオ"}, {"key": "briard", "name": "ブリアード"}, {"key": "white-swiss-shepherd", "name": "ホワイトスイスシェパードドッグ"}, {"key": "bearded-collie", "name": "ビアデッドコリー"}, {"key": "treeing-walker-coonhound", "name": "ツリーイングウォーカークーンハウンド"}, {"key": "central-asian-shepherd", "name": "セントラルアジアシェパードドッグ"}, {"key": "chesapeake-bay-retriever", "name": "チェサピークベイレトリバー"}, {"key": "english-setter", "name": "イングリッシュセッター"}, {"key": "leonberger", "name": "レオンベルガー"}, {"key": "mastiff", "name": "マスティフ"}, {"key": "dogue-de-bordeaux", "name": "ボルドーマスティフ"}, {"key": "belgian-shepherd", "name": "ベルジアンシェパードドッグ"}, {"key": "bullmastiff", "name": "ブルマスティフ"}, {"key": "bull-terrier", "name": "ブルテリア"}, {"key": "bouvier-des-flandres", "name": "ブービエデフランダース"}, {"key": "pharaoh-hound", "name": "ファラオハウンド"}, {"key": "irish-wolfhound", "name": "アイリッシュウルフハウンド"}, {"key": "neapolitan-mastiff", "name": "ナポリタンマスティフ"}, {"key": "tosa", "name": "土佐犬"}, {"key": "irish-setter", "name": "アイリッシュセッター"}, {"key": "saluki", "name": "サルーキ"}, {"key": "irish-terrier", "name": "アイリッシュテリア"}, {"key": "clumber-spaniel", "name": "クランバースパニエル"}, {"key": "english-pointer", "name": "イングリッシュポインター"}];
  const aliases = {
    'バーニーズ・マウンテン・ドッグ':'bernese','バーニーズ':'bernese',
    'ラブラドール':'labrador','ハスキー':'husky','グレート・ピレニーズ':'pyrenees',
    'グレートデーン':'great-dane','ロット・ワイラー':'rottweiler'
  };
  const byName = Object.fromEntries(breeds.map(x=>[x.name,x.key]));
  const byKey = Object.fromEntries(breeds.map(x=>[x.key,x.name]));
  function keyFor(name){ return byName[name] || aliases[name] || 'other'; }
  function nameFor(key){ return byKey[key] || ''; }
  function populateSelect(el){
    if(!el) return;
    const mode=el.dataset.breedMode||'key';
    const includeAll=el.dataset.includeAll==='1';
    const placeholder=el.dataset.placeholder||'';
    const defaultBreed=el.dataset.defaultBreed||'';
    const current=el.value;
    el.innerHTML='';
    if(includeAll){const o=document.createElement('option');o.value='all';o.textContent='すべての大型犬種';el.appendChild(o)}
    else if(placeholder){const o=document.createElement('option');o.value='';o.textContent=placeholder;o.disabled=true;o.selected=true;el.appendChild(o)}
    breeds.forEach(b=>{const o=document.createElement('option');o.value=mode==='name'?b.name:b.key;o.textContent=b.name;el.appendChild(o)});
    if(mode==='name'){if(current && [...el.options].some(o=>o.value===current))el.value=current;else if(defaultBreed)el.value=defaultBreed}
    else if(current && [...el.options].some(o=>o.value===current))el.value=current;
  }
  function updateCounts(el, puppies){
    if(!el) return;
    const counts={};(puppies||[]).forEach(p=>{const k=p.breedKey||keyFor(p.breed);counts[k]=(counts[k]||0)+1});
    [...el.options].forEach(o=>{
      if(o.value==='all'){o.textContent=`すべての大型犬種（${(puppies||[]).length}頭）`;return}
      if(!o.value)return;
      const k=(el.dataset.breedMode||'key')==='name'?keyFor(o.value):o.value;
      const base=(el.dataset.breedMode||'key')==='name'?o.value:(nameFor(o.value)||o.textContent.replace(/（\d+頭）$/,''));
      o.textContent=`${base}（${counts[k]||0}頭）`;
    });
  }
  function populateAll(){document.querySelectorAll('[data-bigpaw-breeds]').forEach(populateSelect)}
  window.BigPawBreedCatalog={breeds,keyFor,nameFor,populateSelect,updateCounts,populateAll};
  populateAll();if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',populateAll);
})();
