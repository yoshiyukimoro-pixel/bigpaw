(function(){
  'use strict';
  const breeds=window.BIGPAW_BREEDS||[];
  if(!breeds.length) return;
  const cache=new Map();
  let selectedKey='all';

  function esc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function stripHtml(s){const d=document.createElement('div');d.innerHTML=s||'';return (d.textContent||'').trim();}
  function wikiArticle(b){return 'https://en.wikipedia.org/wiki/'+encodeURIComponent(b.wiki).replace(/%2F/g,'/');}
  async function getPhoto(b){
    if(cache.has(b.key)) return cache.get(b.key);
    const p=(async()=>{
      const q='https://en.wikipedia.org/w/api.php?action=query&origin=*&format=json&prop=pageimages&piprop=name%7Cthumbnail&pithumbsize=720&redirects=1&titles='+encodeURIComponent(b.wiki);
      const r=await fetch(q,{mode:'cors'}); if(!r.ok) throw new Error('wiki');
      const j=await r.json(); const page=Object.values((j.query&&j.query.pages)||{})[0]||{};
      if(!page.thumbnail||!page.thumbnail.source) throw new Error('no image');
      const file=page.pageimage||'';
      let source=wikiArticle(b), credit='Wikimedia / Wikipedia';
      if(file){
        const cq='https://commons.wikimedia.org/w/api.php?action=query&origin=*&format=json&prop=imageinfo&iiprop=url%7Cextmetadata&titles='+encodeURIComponent('File:'+file);
        try{
          const cr=await fetch(cq,{mode:'cors'}); const cj=await cr.json(); const cp=Object.values((cj.query&&cj.query.pages)||{})[0]||{}; const ii=(cp.imageinfo||[])[0]||{};
          source=ii.descriptionurl||('https://commons.wikimedia.org/wiki/File:'+encodeURIComponent(file));
          const m=ii.extmetadata||{}; const artist=stripHtml(m.Artist&&m.Artist.value); const lic=stripHtml(m.LicenseShortName&&m.LicenseShortName.value);
          credit=[artist,lic].filter(Boolean).join(' / ')||credit;
        }catch(_e){}
      }
      return {src:page.thumbnail.source,source,credit};
    })().catch(()=>({src:'',source:wikiArticle(b),credit:'画像を取得できませんでした'}));
    cache.set(b.key,p); return p;
  }

  function card(b,extraClass=''){
    const btn=document.createElement('button'); btn.type='button'; btn.className='bp-breed-card '+extraClass; btn.dataset.key=b.key; btn.dataset.name=b.ja;
    btn.innerHTML='<span class="bp-breed-photo"><span class="bp-photo-fallback">🐕</span></span><span class="bp-breed-name">'+esc(b.ja)+'</span>';
    const photo=btn.querySelector('.bp-breed-photo');
    const load=async()=>{
      if(btn.dataset.loaded) return; btn.dataset.loaded='1';
      const p=await getPhoto(b); if(!p.src) return;
      const img=document.createElement('img'); img.alt=b.ja; img.loading='lazy'; img.decoding='async'; img.src=p.src;
      const info=document.createElement('a'); info.className='bp-photo-source'; info.href=p.source; info.target='_blank'; info.rel='noopener noreferrer'; info.textContent='ⓘ'; info.title='画像出典・ライセンス: '+p.credit; info.setAttribute('aria-label',b.ja+'の画像出典・ライセンス');
      info.addEventListener('click',e=>e.stopPropagation()); photo.appendChild(img); photo.appendChild(info); const f=photo.querySelector('.bp-photo-fallback'); if(f) f.remove();
    };
    btn._bpLoad=load;
    return btn;
  }

  function observeCards(root){
    const cards=[...root.querySelectorAll('.bp-breed-card')];
    if(!('IntersectionObserver' in window)){cards.forEach(c=>c._bpLoad&&c._bpLoad());return;}
    const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target._bpLoad&&e.target._bpLoad();io.unobserve(e.target)}}),{rootMargin:'350px'});
    cards.forEach(c=>io.observe(c));
  }

  function createModal(){
    if(document.getElementById('bpBreedModal')) return document.getElementById('bpBreedModal');
    const modal=document.createElement('div'); modal.id='bpBreedModal'; modal.className='bp-breed-modal'; modal.setAttribute('role','dialog'); modal.setAttribute('aria-modal','true'); modal.setAttribute('aria-label','犬種を選ぶ');
    modal.innerHTML='<div class="bp-breed-head"><button type="button" class="bp-breed-close" aria-label="閉じる">←</button><h2>犬種を選ぶ</h2><button type="button" class="bp-breed-close bp-x" aria-label="閉じる">×</button></div><div class="bp-breed-searchbar"><input id="bpBreedSearch" type="search" inputmode="search" placeholder="犬種名を検索"><span class="bp-breed-count"></span></div><div class="bp-breed-scroll"><div class="bp-breed-grid"></div><div class="bp-credit-note">写真は各犬種に対応するWikipedia/Wikimedia Commonsの代表画像を犬種名と固定して表示しています。右下のⓘから画像の出典・ライセンスを確認できます。</div></div><div class="bp-breed-bottom"><div class="bp-breed-selected">選択中: <b>すべての大型犬種</b></div><button type="button" class="bp-breed-confirm">決定</button></div>';
    document.body.appendChild(modal);
    const grid=modal.querySelector('.bp-breed-grid');
    breeds.forEach(b=>{const c=card(b); c.addEventListener('click',()=>selectInModal(b.key)); grid.appendChild(c)});
    observeCards(grid);
    const count=modal.querySelector('.bp-breed-count'); count.textContent=breeds.length+'犬種';
    modal.querySelectorAll('.bp-breed-close').forEach(x=>x.addEventListener('click',closeModal));
    modal.querySelector('.bp-breed-confirm').addEventListener('click',()=>{applySelected();closeModal()});
    modal.querySelector('#bpBreedSearch').addEventListener('input',e=>filterModal(e.target.value));
    return modal;
  }
  function filterModal(q){
    q=(q||'').trim().toLowerCase(); let n=0; const modal=createModal();
    modal.querySelectorAll('.bp-breed-card').forEach(c=>{const show=!q||c.dataset.name.toLowerCase().includes(q);c.style.display=show?'':'none';if(show)n++});
    modal.querySelector('.bp-breed-count').textContent=n+'犬種';
  }
  function selectInModal(key){
    selectedKey=key; const modal=createModal();
    modal.querySelectorAll('.bp-breed-card').forEach(c=>c.classList.toggle('selected',c.dataset.key===key));
    const b=breeds.find(x=>x.key===key); modal.querySelector('.bp-breed-selected b').textContent=b?b.ja:'すべての大型犬種';
  }
  function openModal(){
    const select=document.getElementById('breed'); if(select) selectedKey=select.value||'all';
    const modal=createModal(); filterModal(''); modal.querySelector('#bpBreedSearch').value=''; selectInModal(selectedKey); modal.classList.add('open'); document.body.style.overflow='hidden';
  }
  function closeModal(){const modal=document.getElementById('bpBreedModal');if(modal)modal.classList.remove('open');document.body.style.overflow='';}
  function applySelected(){
    const select=document.getElementById('breed'); const trigger=document.getElementById('bpBreedTrigger'); const b=breeds.find(x=>x.key===selectedKey);
    if(select) select.value=b?b.key:'all'; if(trigger) trigger.textContent=b?b.ja:'すべての大型犬種';
  }

  function enhanceSearchSelect(){
    const select=document.getElementById('breed'); if(!select) return;
    select.innerHTML='<option value="all">すべての大型犬種</option>'+breeds.map(b=>'<option value="'+esc(b.key)+'">'+esc(b.ja)+'</option>').join('');
    select.classList.add('bp-hidden-select');
    const trigger=document.createElement('button'); trigger.type='button'; trigger.id='bpBreedTrigger'; trigger.className='bp-breed-trigger'; trigger.textContent='すべての大型犬種'; trigger.addEventListener('click',openModal); select.insertAdjacentElement('afterend',trigger);
    const params=new URLSearchParams(location.search); const q=params.get('breed'); if(q&&breeds.some(b=>b.key===q)){selectedKey=q;select.value=q;applySelected();}
  }

  function enhanceHomeGrid(){
    const old=document.querySelector('#breeds .breed-grid'); if(!old) return;
    old.innerHTML=''; old.classList.add('bp-breed-grid');
    breeds.slice(0,12).forEach(b=>{const c=card(b,'bp-inline-card'); c.addEventListener('click',()=>{selectedKey=b.key;applySelected();openModal();selectInModal(b.key)}); old.appendChild(c)});
    observeCards(old);
    const btn=document.createElement('button'); btn.type='button'; btn.className='bp-all-breeds-btn'; btn.textContent='全60犬種を画像から選ぶ'; btn.addEventListener('click',openModal); old.insertAdjacentElement('afterend',btn);
  }

  function enhanceGuide(){
    if(!/breed-guide\.html$/.test(location.pathname)) return;
    const grid=document.querySelector('.dog-cards'); if(!grid) return;
    grid.innerHTML=''; grid.className='bp-breed-grid';
    breeds.forEach(b=>{const c=card(b); c.addEventListener('click',()=>{location.href='search.html?breed='+encodeURIComponent(b.key)}); grid.appendChild(c)}); observeCards(grid);
    const note=document.createElement('p');note.className='bp-credit-note';note.textContent='全60犬種を写真から選べます。各写真右下のⓘから画像の出典・ライセンスを確認できます。';grid.insertAdjacentElement('afterend',note);
  }

  document.addEventListener('DOMContentLoaded',()=>{enhanceSearchSelect();enhanceHomeGrid();enhanceGuide();});
  window.BigPawBreedPicker={open:openModal,breeds};
})();
